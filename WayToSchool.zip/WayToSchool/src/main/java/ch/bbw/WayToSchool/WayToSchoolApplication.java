package ch.bbw.WayToSchool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WayToSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(WayToSchoolApplication.class, args);
	}

}
